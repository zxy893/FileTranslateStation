﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}
		static bool IsPythonInstalledFromRegistry()
		{
			using (var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Python\PythonCore"))
			{
				if (key != null)
				{
					foreach (var subKeyName in key.GetSubKeyNames())
					{
						// 这里可以进一步检查子键来确定Python的具体版本
						return true; // 如果找到PythonCore，就认为Python已安装
					}
				}
			}
			return false;
		}
		private void log(string ct,TextBox tb)
		{
			tb.Text += "[" + DateTime.Now.ToString() + "]" + ct + "\n";
		}
		private void Form1_DragDrop(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
				foreach (string file in files)
				{
					try
					{
						string filePath = file;
						log("拖放了文件: " + Path.GetFileName(file),textBox1);
						listBox1.Items.Add(Path.GetFileName(file) + "：" + filePath);
						if (File.Exists(filePath))
						{
							DataObject dataObject = new DataObject();
							StringCollection strc = new StringCollection();
							strc.Add(filePath);
							dataObject.SetFileDropList(strc);
							Clipboard.SetDataObject(dataObject);
							log("文件已作为数据对象复制到剪贴板。", textBox1);
							ProcessStartInfo psi = new ProcessStartInfo("Track.py");
							psi.WindowStyle = ProcessWindowStyle.Minimized;
							Process.Start(psi);
						}
						else
						{
							log("文件不存在。", textBox1);
						}
					}
					catch (Exception ex)
					{
						log("处理文件时出错: " + ex.Message, textBox1);
					}
				}
			}
		}
		private void Form1_DragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				e.Effect = DragDropEffects.Copy; // 指示可以执行拖放操作
			}
			else
			{
				e.Effect = DragDropEffects.None; // 指示不能执行拖放操作
			}
		}
		private void button1_Click(object sender, EventArgs e)
		{
			
		}
		
		private void Form1_Load(object sender, EventArgs e)
		{
			解除最高级绑定ToolStripMenuItem.Text = "最高级绑定";
			bool isPythonInstalled = IsPythonInstalledFromRegistry();
			if (isPythonInstalled)
			{
				log("Python is installed.",textBox1);
			}
			else
			{
				log("Python is not installed.",textBox1);
			}
		}

		private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			var filePath=listBox1.SelectedItem.ToString().Split('：')[1];
			if (File.Exists(filePath))
			{
				DataObject dataObject = new DataObject();
				StringCollection strc = new StringCollection();
				strc.Add(filePath);
				dataObject.SetFileDropList(strc);
				Clipboard.SetDataObject(dataObject);
				log("文件已作为数据对象复制到剪贴板。", textBox1);
				ProcessStartInfo psi = new ProcessStartInfo("Track.py");
				psi.WindowStyle = ProcessWindowStyle.Minimized;
				Process.Start(psi);
			}
			else
			{
				log("文件不存在。", textBox1);
			}

		}

		private void button1_Click_1(object sender, EventArgs e)
		{
			listBox1.Items.Clear();
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			string fp = "log.txt";
			if (File.Exists(fp))
			{
				File.Delete(fp);
			}
			File.Create(fp).Close();
			File.WriteAllText(fp,textBox1.Text);
		}

		private void 解除最高级绑定ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string fp = "IsHigest";
			if (File.Exists(fp))
			{
				string at=File.ReadAllText(fp);
				if (at == "1")
				{
					at = "0";
					解除最高级绑定ToolStripMenuItem.Text = "最高级绑定";
					this.TopMost = false;
					File.WriteAllText(fp, at);
				}
				else
				{
					at = "1";
					解除最高级绑定ToolStripMenuItem.Text = "解除最高级绑定";
					this.TopMost = true;
					File.WriteAllText(fp, at);
				}
			}
			else
			{
				var at = "1";
				解除最高级绑定ToolStripMenuItem.Text = "解除最高级绑定";
				this.TopMost = true;
				File.WriteAllText(fp, at);
			}
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			Process[] processes = Process.GetProcessesByName("Python");

			// 遍历所有找到的进程
			foreach (Process process in processes)
			{
				try
				{
					// 尝试结束进程
					process.Kill();
					Console.WriteLine("Process ended: " + process.ProcessName);
				}
				catch (Exception ex)
				{
					// 捕获并处理任何异常（例如，进程可能无法访问）
					Console.WriteLine("Error ending process: " + ex.Message);
				}
			}
		}

		private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Process[] processes = Process.GetProcessesByName("Python");

			// 遍历所有找到的进程
			foreach (Process process in processes)
			{
				try
				{
					// 尝试结束进程
					process.Kill();
				}
				catch (Exception ex)
				{
					// 捕获并处理任何异常（例如，进程可能无法访问）
					MessageBox.Show("Error ending process: " + ex.Message);
				}
			}
			this.Close();
		}
	}
}
